#ifndef E_WORLDS_AUTO
#define E_WORLDS_AUTO

#include "AutoScripts/AWP.hpp"

extern void AWP(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

extern void AWPMid(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

extern void LeftHalfNC(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

extern void LeftHalfCover(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

extern void RightHalfNC(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

extern void RightHalfCover(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

extern void RightDNNC(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

extern void RightDNCover(EDrive * E_drive
        , Arm * E_arm
        , RearClamp * E_rearclamp
        , RingMech * E_ringmech
        , shared_ptr<OdomState> truePose);

#endif