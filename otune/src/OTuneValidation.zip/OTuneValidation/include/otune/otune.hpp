#ifndef OTUNE_HEADER
#define OTUNE_HEADER

#include "ros_lib/ros.h"
#include "ros_lib/ros/publisher.h"

#include "ros_lib/std_msgs/String.h"
#include "ros_lib/std_msgs/Bool.h"
#include "ros_lib/std_msgs/Int16.h"

#include "main.h"
#include "okapi/api/units/QAngle.hpp"
#include <string>


namespace otune{
    enum OdometryTuningMode {BackCenterWheelConfig = 1, LeftRightWheelConfig};

    extern ros::NodeHandle nh;

    // publisher: odom velocity info publisher
    extern std_msgs::String velocityMsg;
    extern int tuningModeMsg;
    extern int recordingProgress;
    extern char* msg;
    extern ros::Publisher odomVelocityPublisher;
   
    // Initialize OTune
    void initOTune(const OdometryTuningMode& mode);

    // publish message
    void publishMsg(const double& progr, const int& v1, const int& v2);
    void publishMsg(const double& progr, const int& v1, const int& v2, const int& v3);
}

#endif