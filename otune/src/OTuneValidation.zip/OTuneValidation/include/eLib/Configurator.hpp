#ifndef _ETP20_CONFIGURATOR_
#define _ETP20_CONFIGURATOR_

#include "eLib/utils/EUnits.hpp"
using namespace okapi;

#include "eLib/eDriver/EDriver.hpp"
#include "eLib/eSLAM/localization/EOdometry.hpp"
using namespace elib;


//---------------------------------------
// 
// PROGRAM SETUP
// 
// -- Whether Stable Release
// -- Debug Mode Tester
//---------------------------------------
#define STABLE_RELEASE false


// Control
#define LeftDriveStick ANALOG_LEFT_Y
#define RightDriveStick ANALOG_RIGHT_Y


//---------------------------------------
//
// General Motor Macros
//
//---------------------------------------
#define motor_brake_coast pros::E_MOTOR_BRAKE_COAST
#define motor_gearset_100 pros::E_MOTOR_GEARSET_36
#define motor_gearset_200 pros::E_MOTOR_GEARSET_18
#define motor_gearset_600 pros::E_MOTOR_GEARSET_06




//---------------------------------------
// 
// DriveTrain Parameters
// 
//---------------------------------------
// Compiler Def
#define USING_GPS true
#define USING_TURN_IN_PURSUIT false

#define DriveStickQuadraticCoeff 0.732421875  //    X / 128 (normalize square) / 128 (normalize by move() function) * 12000 (scale to move_voltage())


// Motors
static const MotorConfig driveLF_cfg(18, true, motor_gearset_600, motor_brake_coast);
static const MotorConfig driveLM_cfg(8, false, motor_gearset_600, motor_brake_coast);
static const MotorConfig driveLB_cfg(17, true, motor_gearset_600, motor_brake_coast);
static const MotorConfig driveRF_cfg(10, false, motor_gearset_600, motor_brake_coast);
static const MotorConfig driveRM_cfg(15, true, motor_gearset_600, motor_brake_coast);
static const MotorConfig driveRB_cfg(13, false, motor_gearset_600, motor_brake_coast);

// Drivetrain Dimentions
// Separation between the CENTER of the Left and Right solid rubber wheels. 
static const QLength driveWheelSeparation = 13_in;
// The radius of the solid rubber wheel on the drivetrain
static const QLength driveWheelDiameter = 2.75_in;

//---------------------------------------
// PID 
//---------------------------------------
// static PidConfig drivePursuitPidConfig(20,300,95,0,7200,0.25);
static PidConfig drivePursuitPidConfig(30,  2,60,0,100,1400);
static PidConfig driveTurnPidConfig(   35,  6,100,0,50,1000,12000,2000);
static PidConfig driveHoldPidConfig(   100,0,0,0,0,0);











//---------------------------------------
// 
// GPS Parameters
// 
//---------------------------------------
#if USING_GPS

#define USING_PATH_FINDING true

// IMUs
// Top IMU
static const IMUConfig gps_imu1_config(4, 1, 0, 2, true, true, true);
// Bottom IMU
static const IMUConfig gps_imu2_config(5, 1, 0, 2, false, true, false);

// Tracking Wheels
static const TrackingWheelConfig ltrkwhlconfig(1,false, 2.75_in);
static const TrackingWheelConfig rtrkwhlconfig(3, true, 2.75_in);

static const TrackingWheelConfig ctrkwhlconfig(9,false, 2.75_in);
static const TrackingWheelConfig btrkwhlconfig(11, true, 2.75_in);

// Odom Chassis Config
static const OdomChassisConfig LRChassisCfg(7_in, 11_in, 7.5_in, 7.5_in, 3.8_in, 3.8_in);
static const OdomChassisConfig CBChassisCfg(7_in, 11_in, 7.5_in, 7.5_in, 0_in,   0_in,  2.6_in);
// Initialize a Pose
static const OdomState initPose(0_in, 0_in, 90_deg);
#endif



#endif