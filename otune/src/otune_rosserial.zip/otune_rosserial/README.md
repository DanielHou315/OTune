# OTune_rosserial template 
1. use PROS Conductor to fetch and apply the template
2. In initialize() function, initialize otune by calling
    - otune::initOTune(OdometryTuningMode mode);
2. In your main loop or odometry task 
    - whichever periodically takes input from your odom wheels, 
    - get the rotation sensor velocity by
        - calling sensor.get_velocity() if it is a pros::Rotation
        - calling sensor.getVelocity() if it is an elib::ERotation
    - Call the publish message function and strictly follow the following parameter orders: 
        - publishMsg(double progress, double v1, double v2)
            - If your Wheel Configuration is LR
                - v1 == L-velocity
                - v2 == R-velocity
            - If your Wheel Configuration is CB
                - v1 == C-velocity
                - v2 == B-velocity
        - publishMsg(double progress, double v1, double v2, double v3)
            - If your Wheel Configuration is LRB
                - v1 == L-velocity
                - v2 == R-velocity
                - v3 == B-velocity
   